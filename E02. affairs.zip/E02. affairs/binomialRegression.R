# -------------------------------------
# Miguel A. Castellanos
# septiembre 2024
# -------------------------------------

# Leemos los datos, los preparamos y los guardamos en un csv
data <- read.csv("Affairs.csv")
names(data)
data <- data[-1]

data$affairs[data$affairs>0]  <- 1
data$gender <- ifelse(data$gender == "male", 0, 1)
data$children <- ifelse(data$children == "no", 0, 1)
write.csv(data,"data-affairs.csv", row.names = FALSE)

# Calculamos el modelo binomial completo sobre TODOS los datos
full.model <- glm(affairs~., data=data, family=binomial)
summary(full.model)

# Vemos las predicciones y calculamos su precision
p <- predict(full.model, data, "response")
p <- ifelse(p<0.5, 0, 1)
(tab <- table(data$affairs, p))
(accuracy <- sum(diag(tab)) / sum(tab))

# --------------------------------------
# Repetimos pero ahora entrenamos con train y evaluamos con test


# Predicciones y precision
p <- predict(full.model, test, "response")
p <- ifelse(p<0.5, 0, 1)
(tab <- table(test$affairs, p))
(accuracy <- sum(diag(tab)) / sum(tab))
