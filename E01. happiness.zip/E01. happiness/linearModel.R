# -------------------------------------
# Miguel A. Castellanos
# septiembre 2024
# -------------------------------------


# Leemos los datos, los preparamos y los guardamos en un csv
data <- read.csv("world-happiness-report-personas.csv")
data <- data[-1]
write.csv(data,"data-happiness.csv", row.names = FALSE)

# Calculamos el modelo completo
full.model <- lm(Life.Ladder~., data=data)
summary(full.model)

# Calculamos el mse
(mse <- mean(full.model$residuals^2))

# Estandarizamos los coeficientes para interpretar los pesos
d2 <- as.data.frame(scale(data))

full.model <- lm(Life.Ladder~., data=d2)
summary(full.model)
(mse <- mean(full.model$residuals^2))


# Innecesario
# library(MASS)
# step.model <- stepAIC(full.model, direction = "both", trace = FALSE)
